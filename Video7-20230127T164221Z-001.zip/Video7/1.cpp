#include<bits/stdc++.h>
using namespace std;

class student{
    string name;
    int id;
};

int main(){
    student s1;
    return 0;
}